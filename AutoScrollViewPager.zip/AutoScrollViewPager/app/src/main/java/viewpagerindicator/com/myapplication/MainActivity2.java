package viewpagerindicator.com.myapplication;

import android.os.Bundle;
import android.support.v4.view.PagerAdapter;
import android.support.v7.app.AppCompatActivity;

public class MainActivity2 extends AppCompatActivity {

    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        AutoScrollViewPager viewPager = (AutoScrollViewPager) findViewById(R.id.view_pager);
        ImageAdapter imgadapter = new ImageAdapter(this);

        PagerAdapter wrappedAdapter = new InfinitePagerAdapter(imgadapter);

        viewPager.setAdapter(wrappedAdapter);
        viewPager.startAutoScroll();

    }
}
